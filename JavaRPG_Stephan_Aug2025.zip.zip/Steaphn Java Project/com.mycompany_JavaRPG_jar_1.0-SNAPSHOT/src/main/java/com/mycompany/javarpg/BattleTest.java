/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.mycompany.javarpg;

/**
 *
 * @author Stephan Bennett
 */

/**
 * BattleTest.java
 * This file tests the core battle mechanics between Player and Enemy.
 * Not part of final gameplay. Used for debugging and validation.
 */

public class BattleTest {
    public static void main(String[] args) {
        Player player = new Player("Stephan",1);
        Enemy enemy = new Enemy("Goblin");
        
        System.out.println("Battle begins between " + player.getName() + " and " + enemy.getName());
        
        while (player.isAlive() && enemy.isAlive()){
            enemy.takeDamage(5);
            System.out.println(enemy.getName() + " take 5 damage. HP: " + enemy.getHealth());
         player.takeDamage(3);
            System.out.println(player.getName() + " takes 3 damage. HP: " + player.getHealth());

            System.out.println("---");
        }

        if (player.isAlive()) {
            System.out.println(player.getName() + " wins!");
        } else {
            System.out.println(enemy.getName() + " wins!");
        }
        }
}

