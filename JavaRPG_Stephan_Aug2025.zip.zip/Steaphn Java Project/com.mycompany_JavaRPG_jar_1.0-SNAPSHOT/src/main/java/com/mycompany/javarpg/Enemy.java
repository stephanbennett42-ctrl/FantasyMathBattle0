/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javarpg;

/**
 *
 * @author Steven Bennett
 */
public class Enemy {
    private String name;
    private int health;
    
    public Enemy(String name){
        this.name = name;
        this.health = 15; //Stating HP
    }
    public Enemy(String name, int health) {
    this.name = name;
    this.health = health;
}

    
    public String getName(){
        return name;
    }
    
    public int getHealth(){
        return health;
    }
    public void takeDamage(int damage){
        health = Math.max(0, health - damage);
    }
    
    public boolean isAlive() {
        return health > 0;
   }
}
