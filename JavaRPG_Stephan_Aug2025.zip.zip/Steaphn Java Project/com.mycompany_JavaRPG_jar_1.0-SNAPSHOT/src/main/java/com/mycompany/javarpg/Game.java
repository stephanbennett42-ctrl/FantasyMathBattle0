/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javarpg;

/**
 *
 * @author Steven Bennett
 */

import java.util.Scanner;

public class Game {
    public static void main(String[] args) {
        Player player = new Player("Stephan", 100);
        Enemy enemy = new Enemy("Goblin", 50);

        Scanner scanner = new Scanner(System.in);
        System.out.println("Choose battle system: 1 = Old, 2 = New");
        int choice = scanner.nextInt();

        BattleSystem battleSystem = (choice == 1) ? new OldBattleSystem() : new NewBattleSystem();
        battleSystem.startBattle(player, enemy);
    }
}
    

