/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javarpg;

/**
 *
 * @author Stephan Bennett
 */
public class JavaRPG {

    public static void main(String[] args) {
        Player player = new Player("Stephan", 100);
        Enemy enemy = new Enemy("Goblin", 50);

        System.out.println("Welcome, " + player.getName() + "!");
        System.out.println("Health: " + player.getHealth());
        System.out.println("Score: " + player.getScore());

        System.out.println("\nAn enemy appears!");

        while (player.isAlive() && enemy.getHealth() > 0) {
            System.out.println("\nYou attack the enemy!");
            enemy.takeDamage(20);
            player.addScore(10);
            System.out.println("Enemy health: " + enemy.getHealth());

            if (enemy.getHealth() > 0) {
                System.out.println("Enemy strikes back!");
                player.takeDamage(15);
                System.out.println("Your health: " + player.getHealth());
            }
        }

        if (player.isAlive()) {
            System.out.println("\nVictory! Final score: " + player.getScore());
        } else {
            System.out.println("\nYou were defeated...");
        }

       
    }
}
