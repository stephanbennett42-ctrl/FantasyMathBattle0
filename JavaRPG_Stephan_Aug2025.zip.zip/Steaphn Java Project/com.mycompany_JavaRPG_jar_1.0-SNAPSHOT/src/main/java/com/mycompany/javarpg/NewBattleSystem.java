/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.mycompany.javarpg;

/**
 *
 * @author Stephan Bennett
 */

import java.util.Scanner;

public class NewBattleSystem implements BattleSystem {

    @Override
    public void startBattle(Player player, Enemy enemy) {
        Scanner scanner = new Scanner(System.in);

        while (player.isAlive() && enemy.isAlive()) {
            System.out.println("\n" + player.getName() + " HP: " + player.getHealth() + " | Score: " + player.getScore());
            System.out.println(enemy.getName() + " HP: " + enemy.getHealth());

            int damage = getPlayerAttack(scanner, enemy);
            if (damage > 0) {
                enemy.takeDamage(damage);
                player.addScore(10);
            }

            int enemyDamage = 3;
            player.takeDamage(enemyDamage);
            System.out.println(enemy.getName() + " strikes back for " + enemyDamage + " damage!");
        }

        System.out.println(player.isAlive() ? "Victory!" : "Defeat...");
    }

    private int getPlayerAttack(Scanner scanner, Enemy enemy) {
        while (true) {
            System.out.println("\nChoose your attack:");
            System.out.println("1. Basic Strike");
            System.out.println("2. Prime Strike");
            System.out.println("3. Modulus Strike");
            System.out.print("Enter 1-3: ");

            try {
                int choice = scanner.nextInt();
                switch (choice) {
                    case 1:
                        System.out.println("Basic Strike was effective!");
                        return 5;
                    case 2:
                        if (isPrime(enemy.getHealth())) {
                            System.out.println("Prime Strike hits hard! Enemy HP was prime.");
                            return 10;
                        } else {
                            System.out.println("Prime Strike grazes the enemy. HP wasn't prime.");
                            return 2;
                        }
                    case 3:
                        int modDamage = enemy.getHealth() % 7;
                        if (modDamage < 3) modDamage = 3;
                        System.out.println("Modulus Strike deals " + modDamage + " damage!");
                        return modDamage;
                    default:
                        System.out.println("Invalid choice.");
                }
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next(); // clear bad input
            }
        }
    }

    private boolean isPrime(int num) {
        if (num <= 1) return false;
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) return false;
        }
        return true;
    }
}