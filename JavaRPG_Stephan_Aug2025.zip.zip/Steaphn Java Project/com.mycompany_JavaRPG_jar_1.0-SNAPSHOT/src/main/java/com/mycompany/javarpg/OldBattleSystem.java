/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javarpg;

/**
 *
 * @author Steven Bennett
 */
import java.util.Scanner;

public class OldBattleSystem implements BattleSystem {

    @Override
    public void startBattle(Player player, Enemy enemy) {
        Scanner scanner = new Scanner(System.in);

        while (player.isAlive() && enemy.isAlive()) {
            System.out.println("\n" + player.getName() + " HP: " + player.getHealth());
            System.out.println(enemy.getName() + " HP: " + enemy.getHealth());

            int damage = getPlayerAttack(scanner);
            if (damage > 0) {
                enemy.takeDamage(damage);
                player.addScore(10);
            }

            int enemyDamage = 3;
            player.takeDamage(enemyDamage);
            System.out.println(enemy.getName() + " strikes back for " + enemyDamage + " damage!");
        }

        System.out.println(player.isAlive() ? "Victory!" : "Defeat...");
    }

    private int getPlayerAttack(Scanner scanner) {
        while (true) {
            System.out.println("\nChoose your attack:");
            System.out.println("1. Basic Strike");
            System.out.println("2. Prime Strike");
            System.out.println("3. Modulus Strike");
            System.out.print("Enter 1-3: ");

            try {
                int choice = scanner.nextInt();
                switch (choice) {
                    case 1:
                        System.out.println("Basic Strike was effective!");
                        return 5;
                    case 2:
                        System.out.println("Prime Strike had no effect.");
                        return 0;
                    case 3:
                        System.out.println("Modulus Strike had no effect.");
                        return 0;
                    default:
                        System.out.println("Invalid choice.");
                }
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next(); // clear bad input
            }
        }
    }
}