/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author Steven Bennett
 */
package com.mycompany.javarpg;

public class Player {
    private final String name;
    private int health;
    private int score;

    public Player(String name, int health) {
        this.name = name;
        this.health = health;
        this.score = 0;
    }

    public String getName() {
        return name;
    }

    public int getHealth() {
        return health;
    }

    public int getScore() {
        return score;
    }

    public void takeDamage(int damage) {
        health -= damage;
        if (health < 0) health = 0;
    }

    public void addScore(int points) {
        score += points;
    }

    public boolean isAlive() {
        return health > 0;
    }
}
